#pragma once
#include <D3DCore/D3D11_GameApp.h>
#include <Manager/SceneManager.h>

class StartApp : public D3D11_GameApp
{
public:
	StartApp();
	~StartApp();
};